#define ERROR1 1
#define ERROR2 2
#define ERROR3 3

#define ERROR4 4
#define ERROR5 5
#define ERROR6 6
#define ERROR7 7
#define ERROR8 8
#define ERROR9 9

#define ERROR 50

#define NOTHING 1000

#define START_LINE 1
#define START_POSITION 0

#define SAVE 1
#define LOAD 0
