#ifndef _PRINT_H_
#define _PRINT_H_

#include "base.h"
#include "define.h"

class Print
{
	public:
		string print_int(string name);
		string print_str(string s);
};

#endif
