#ifndef _BASE_H_
#define _BASE_H_

#include <iostream>
#include <map>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>
#include <sstream>

#define OPERATOR -1
#define PAREN -2

using namespace std;

#endif
